/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package work03;

/**
 *
 * @author feoy1
 */
public class MyUtil {

    public static double calculteBmi(double weight,double height){
        return weight / (height*height);
    }
    public static double average(int v1,int v2,int v3){
        return (v1+v2+v3) / 3;
    }
}
