import MyUtil;
public class work03UseofUtilityClass {
    public static void main(String[] args) {
        double bmi = calculateBMI(80,170);
        System.out.println(bmi);
    }
}
