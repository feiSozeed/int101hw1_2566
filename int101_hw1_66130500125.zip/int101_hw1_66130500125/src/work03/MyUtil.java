public class MyUtil {
    public double calculteBMI(double weight,double height){
        return height / (weight*weight);
    }

    public double average(int v1,int v2, int v3){
        return (v1+v2+v3) / 3;
    }
}
